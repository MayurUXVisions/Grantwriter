<section class="subscriber-section">
   
    <div class="subscriber-text" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/subscriber-bg.jpg);">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/grant-siren-logo.svg" alt="" >
        <h3>instant <strong>Grant Alerts</strong> at Your Finger Tips</h3>
        <a class="ghost-btn white-ghost" href="#">SUBSCRIBE TO GRANT SIREN</a>
    </div>

</section>
