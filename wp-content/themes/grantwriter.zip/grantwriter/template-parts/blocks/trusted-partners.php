<section class="trusted-partner">
    <div class="container">
    
        <div class="trusted-partner__flex">
            <h2>Trusted <strong>Partners</strong></h2>
            <div class="trustedSwiper swiper">
                <div class="swiper-wrapper"> 
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ascd_logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/CherokeeNation_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ChildrensHospitalLA_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/SacramentoSheriffis_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/Yale_logo.png" alt="" ></div> 
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/USDA_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/SaferFoundation_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/TempleUniversity_Logo.png" alt="" ></div>
                    <div class="swiper-slide"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/SchoolofPhilidelphia_Logo.png" alt="" ></div>
                </div>
            </div>
        </div>

    </div>
</section>