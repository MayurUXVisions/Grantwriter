<section class="home-hero">
	<div class="home-hero__bg" >
		<div class="home-hero__video">
			<video loop="true" preload="none" autoplay="autoplay" muted="" playinline="" playsinline="" webkit-playsinline="">
				<source src="<?php echo site_url(); ?>/wp-content/uploads/2024/08/gw-homehero.mp4" type="video/mp4">
			</video>
		</div> 
		<div class="container home-hero__flex" data-aos="fade-up">
			<label>America’s #1 Grant Writers, since 1995</label>
			<h1>We’re the Difference Between <strong>Success</strong> and Reject</h1>
			<ul>
				<li>We Write Grants</li>
				<li>Win Grant Funds</li>
				<li>Target Awardable RFP’s</li>
			</ul>
		</div>
	</div>
</section>

